package com.example.proyectofinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.example.proyectofinal.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // MOSTRAR / OCULTAR CONTRASEÑA CON EL ICONO DEL OJO
        ImageView imageViewShowPwd = findViewBy(R.id.iVShowPass);
        imageViewShowPwd.setImageResource(R.drawable.iVHidePass);
        imageViewShowPwd.setOnClickListener
    }
}